//
// TestRunner.h
//


#ifndef Poco_CppUnit_TestRunner_INCLUDED
#define Poco_CppUnit_TestRunner_INCLUDED

#include "CppUnit/TestRunner.h"

#endif // Poco_CppUnit_TestRunner_INCLUDED
