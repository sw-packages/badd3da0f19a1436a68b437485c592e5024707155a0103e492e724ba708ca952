//
// TestResult.h
//


#ifndef Poco_CppUnit_TestResult_INCLUDED
#define Poco_CppUnit_TestResult_INCLUDED

#include "CppUnit/TestResult.h"

#endif // Poco_CppUnit_TestResult_INCLUDED
